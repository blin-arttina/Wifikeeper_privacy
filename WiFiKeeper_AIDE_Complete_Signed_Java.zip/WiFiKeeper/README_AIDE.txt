WiFiKeeper — AIDE-ready (Java), signed release

Install & build (copy/paste):
1) Unzip the 'WiFiKeeper' folder into: /storage/emulated/0/AIDEProjects/
2) Ensure your keystore exists at:
   /storage/emulated/0/AIDEProjects/keystores/wifikeeper-release.keystore
   (edit app/build.gradle if yours differs)
3) In AIDE: Projects → Open Project → WiFiKeeper
4) Build → Build APK (Release)
5) Install: app/build/outputs/apk/release/app-release.apk

Notes:
• Foreground service + Wi-Fi high-perf lock + CPU partial wakelock
• Persistent notification, auto-reconnect, starts on boot
• Dark mode default, menu toggles theme
• Footer text: “Blind Art 2025”
• No Google Play plugin; no license prompts
