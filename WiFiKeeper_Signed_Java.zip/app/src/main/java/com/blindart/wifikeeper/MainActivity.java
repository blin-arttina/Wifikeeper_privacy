
package com.blindart.wifikeeper;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.widget.SwitchCompat;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_POST_NOTIF = 1001;
    private SwitchCompat toggle;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);

        status = new TextView(this);
        status.setText("Service is OFF");
        status.setTextSize(18f);

        toggle = new SwitchCompat(this);
        toggle.setText("Wi‑Fi Keeper");
        toggle.setChecked(false);
        toggle.setOnCheckedChangeListener((btn, isOn) -> {
            if (isOn) {
                startService(new Intent(this, WiFiKeeperService.class));
                status.setText("Service is ON");
                status.setTextColor(0xFF2E7D32);
            } else {
                stopService(new Intent(this, WiFiKeeperService.class));
                status.setText("Service is OFF");
                status.setTextColor(0xFF555555);
            }
        });

        Button privacy = new Button(this);
        privacy.setText("View Privacy Policy");
        privacy.setOnClickListener(v -> startActivity(new Intent(this, PrivacyPolicyActivity.class)));

        root.addView(status);
        root.addView(toggle);
        root.addView(privacy);

        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_POST_NOTIF);
            }
        }
    }
}
