
package com.example.wifikeeper;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {
    private static final String HOSTED_POLICY = "https://blindart2020.github.io/wifikeeper-privacy/";
    private static final String FALLBACK = "file:///android_asset/privacy_policy.html";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        String mode = getIntent().getStringExtra("mode");
        setTitle("privacy".equals(mode) ? "Privacy Policy" : "About");

        WebView web = findViewById(R.id.web);
        web.getSettings().setJavaScriptEnabled(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public void onReceivedError(WebView v,int c,String d,String u){ v.loadUrl(FALLBACK); }
        });

        if ("privacy".equals(mode)) web.loadUrl(HOSTED_POLICY);
        else web.loadData(
                "<html><body style='background:#000;color:#eee;font:16px system-ui'>" +
                "<h2>WiFiKeeper</h2><p>Keeps your Wi‑Fi awake. No tracking. On‑device only.</p>" +
                "<p><b>Contact:</b> blindart2020@gmail.com</p>" +
                "<p><a style='color:#8be78b' href='"+HOSTED_POLICY+"'>Privacy Policy</a></p>" +
                "</body></html>", "text/html","utf-8");
    }
}
