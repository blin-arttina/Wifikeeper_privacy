
package com.example.wifikeeper;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Switch;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.example.wifikeeper.core.KeepAliveService;

public class MainActivity extends AppCompatActivity {

    private Switch toggle;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggle = findViewById(R.id.toggleWifiKeeper);
        status = findViewById(R.id.txtStatus);

        toggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) startForegroundServiceCompat();
            else {
                stopService(new Intent(this, KeepAliveService.class));
                status.setText("Stopped");
            }
        });

        findViewById(R.id.btnRequestIgnoreOptimizations).setOnClickListener(v -> requestIgnoreBatteryOptimizations());
    }

    private void startForegroundServiceCompat() {
        Intent i = new Intent(this, KeepAliveService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
        else startService(i);
        status.setText("Running…");
    }

    private void requestIgnoreBatteryOptimizations() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        if (id == R.id.menu_privacy) {
            startActivity(new Intent(this, AboutActivity.class).putExtra("mode", "privacy"));
            return true;
        }
        if (id == R.id.menu_about) {
            startActivity(new Intent(this, AboutActivity.class).putExtra("mode", "about"));
            return true;
        }
        if (id == R.id.menu_logs) {
            startActivity(new Intent(this, LogActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
