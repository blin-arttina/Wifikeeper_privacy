
package com.blindart.wifikeeper;

import android.os.Bundle;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;

public class PrivacyPolicyActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView wv = new WebView(this);
        wv.getSettings().setJavaScriptEnabled(false);
        wv.loadUrl("file:///android_asset/privacy_policy.html");
        setContentView(wv);
        setTitle("Privacy Policy");
    }
}
