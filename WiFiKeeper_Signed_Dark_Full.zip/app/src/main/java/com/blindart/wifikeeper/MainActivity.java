
package com.blindart.wifikeeper;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.widget.SwitchCompat;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_POST_NOTIF = 1001;
    private SwitchCompat toggle;
    private TextView status;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.statusText);
        toggle = findViewById(R.id.toggleSwitch);
        Button privacy = findViewById(R.id.privacyButton);
        prefs = getSharedPreferences("wifikeeper", MODE_PRIVATE);

        boolean wasOn = prefs.getBoolean("service_on", false);
        toggle.setChecked(wasOn);
        setUi(wasOn, false);

        toggle.setOnCheckedChangeListener((btn, isOn) -> {
            setUi(isOn, true);
            if (isOn) {
                startService(new Intent(this, WiFiKeeperService.class));
            } else {
                stopService(new Intent(this, WiFiKeeperService.class));
            }
        });

        privacy.setOnClickListener(v -> startActivity(new Intent(this, PrivacyPolicyActivity.class)));

        // Ask for notifications on Android 13+ so the foreground service notification is visible
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_POST_NOTIF);
            }
        }
    }

    private void setUi(boolean on, boolean persist) {
        if (on) {
            status.setText("Service is ON");
            status.setTextColor(0xFF2E7D32); // green
        } else {
            status.setText("Service is OFF");
            status.setTextColor(0xFFFFFFFF); // white
        }
        if (persist) {
            prefs.edit().putBoolean("service_on", on).apply();
        }
    }
}
