
package com.blindart.wifikeeper;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ScrollView;
import android.widget.TextView;

public class PrivacyPolicyActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Privacy Policy");

        ScrollView scroll = new ScrollView(this);
        TextView tv = new TextView(this);
        tv.setText("Wi‑Fi Keeper Privacy Policy:\n\n"
            + "• No personal data is collected, stored, or shared.\n"
            + "• The app uses temporary system locks (Wi‑Fi lock and CPU wake lock) to keep your connection active while ON.\n"
            + "• No analytics, ads, or network calls are performed by the app.\n\n"
            + "Permissions used:\n"
            + "• WAKE_LOCK — keep CPU awake while service runs.\n"
            + "• ACCESS_WIFI_STATE / CHANGE_WIFI_STATE — manage Wi‑Fi lock.\n"
            + "• FOREGROUND_SERVICE — required for the persistent notification.\n"
            + "• POST_NOTIFICATIONS (Android 13+) — to show the foreground notification.");
        tv.setPadding(24, 24, 24, 24);
        scroll.addView(tv);
        setContentView(scroll);
    }
}
