package com.blindart.wifikeeper;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_POST_NOTIF = 1001;
    private SwitchCompat toggle;
    private TextView status;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences tp = getSharedPreferences("wifikeeper", MODE_PRIVATE);
        boolean light = tp.getBoolean("light_theme", false);
        AppCompatDelegate.setDefaultNightMode(light ? AppCompatDelegate.MODE_NIGHT_NO : AppCompatDelegate.MODE_NIGHT_YES);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.statusText);
        toggle = findViewById(R.id.toggleSwitch);
        Button privacy = findViewById(R.id.privacyButton);
        Button logsBtn = findViewById(R.id.logsButton);
        prefs = getSharedPreferences("wifikeeper", MODE_PRIVATE);

        boolean wasOn = prefs.getBoolean("service_on", false);
        toggle.setChecked(wasOn);
        setUi(wasOn, false);

        boolean autoStart = prefs.getBoolean("auto_start_on_open", false);
        if (autoStart && !wasOn) {
            LogStore.add(this, "Auto-start on app open");
            startService(new Intent(this, WiFiKeeperService.class));
            setUi(true, true);
            toggle.setChecked(true);
        }

        toggle.setOnCheckedChangeListener((btn, isOn) -> {
            setUi(isOn, true);
            if (isOn) {
                LogStore.add(this, "Toggle ON -> starting service");
                startService(new Intent(this, WiFiKeeperService.class));
            } else {
                LogStore.add(this, "Toggle OFF -> stopping service");
                stopService(new Intent(this, WiFiKeeperService.class));
            }
        });

        logsBtn.setOnClickListener(v -> startActivity(new Intent(this, LogActivity.class)));
        privacy.setOnClickListener(v -> startActivity(new Intent(this, AboutActivity.class)));

        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_POST_NOTIF);
            }
        }
    }

    private void setUi(boolean on, boolean persist) {
        if (on) { status.setText("Service is ON"); status.setTextColor(0xFF2E7D32); }
        else { status.setText("Service is OFF"); status.setTextColor(0xFFFFFFFF); }
        if (persist) prefs.edit().putBoolean("service_on", on).apply();
    }

    @Override public boolean onCreateOptionsMenu(Menu menu) { getMenuInflater().inflate(R.menu.main_menu, menu); return true; }
    @Override public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==R.id.menu_settings){ startActivity(new Intent(this, SettingsActivity.class)); return true; }
        if (item.getItemId()==R.id.menu_about){ startActivity(new Intent(this, AboutActivity.class)); return true; }
        if (item.getItemId()==R.id.menu_logs){ startActivity(new Intent(this, LogActivity.class)); return true; }
        return super.onOptionsItemSelected(item);
    }
}
