package com.blindart.wifikeeper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = context.getSharedPreferences("wifikeeper", Context.MODE_PRIVATE);
        if (prefs.getBoolean("service_on", false)) {
            LogStore.add(context, "Boot completed -> restarting service");
            context.startService(new Intent(context, WiFiKeeperService.class));
        }
    }
}
