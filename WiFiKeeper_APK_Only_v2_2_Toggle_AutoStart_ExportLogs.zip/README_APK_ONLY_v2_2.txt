WiFiKeeper v2.2 (APK-only) — Notification Toggle, Auto-Start on Open, Exportable Logs

Build (AIDE):
1) Copy folder to: /storage/emulated/0/AIDEProjects/WiFiKeeper_APK_Only_v2_2_Toggle_AutoStart_ExportLogs/
2) AIDE → Open Project → WiFiKeeper_APK_Only_v2_2_Toggle_AutoStart_ExportLogs
3) Build → Build APK (Release)
4) APK output:
   app/build/outputs/apk/release/WiFiKeeper_v2.2_release.apk

New in 2.2:
• Notification actions: Toggle + Stop
• Settings → "Start service when app opens"
• Logs: Share, Export (lets you pick a folder via system file picker), Clear
• Global crash capture added to logs

Quick Settings Tile:
• Pull down → Edit → drag "WiFiKeeper" tile into active area.
• Tap tile to toggle service (tile lights when ON).

Privacy:
• No data collection; About menu opens policy and has offline fallback.
