package com.wifikeeper;

import android.os.Bundle;
import android.widget.Switch;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Switch wifiSwitch = findViewById(R.id.wifiSwitch);
        wifiSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                wifiSwitch.setText("Wi-Fi Keeper: ON");
                wifiSwitch.setTextColor(0xFF00FF00); // Green text when on
                Toast.makeText(this, "Wi-Fi Keeper Enabled", Toast.LENGTH_SHORT).show();
            } else {
                wifiSwitch.setText("Wi-Fi Keeper: OFF");
                wifiSwitch.setTextColor(0xFFFFFFFF); // White text when off
                Toast.makeText(this, "Wi-Fi Keeper Disabled", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
