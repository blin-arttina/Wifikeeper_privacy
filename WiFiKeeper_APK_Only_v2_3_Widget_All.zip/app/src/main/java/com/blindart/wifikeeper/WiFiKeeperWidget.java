package com.blindart.wifikeeper;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class WiFiKeeperWidget extends AppWidgetProvider {

    public static final String ACTION_WIDGET_TOGGLE = "com.blindart.wifikeeper.WIDGET_TOGGLE";

    private static boolean isOn(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences("wifikeeper", Context.MODE_PRIVATE);
        return prefs.getBoolean("service_on", false);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateAll(context, appWidgetManager);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent != null && ACTION_WIDGET_TOGGLE.equals(intent.getAction())) {
            boolean next = !isOn(context);
            context.getSharedPreferences("wifikeeper", Context.MODE_PRIVATE).edit().putBoolean("service_on", next).apply();
            if (next) context.startService(new Intent(context, WiFiKeeperService.class));
            else context.stopService(new Intent(context, WiFiKeeperService.class));
            LogStore.add(context, "Widget -> " + (next ? "start service" : "stop service"));
            requestUpdate(context);
        }
    }

    public static void requestUpdate(Context context) {
        AppWidgetManager awm = AppWidgetManager.getInstance(context);
        updateAll(context, awm);
    }

    private static void updateAll(Context context, AppWidgetManager awm) {
        ComponentName thisWidget = new ComponentName(context, WiFiKeeperWidget.class);
        int[] ids = awm.getAppWidgetIds(thisWidget);
        for (int id : ids) {
            RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.widget_wifikeeper);
            boolean on = isOn(context);
            rv.setTextViewText(R.id.widgetText, on ? "WiFi ON" : "WiFi OFF");
            rv.setInt(R.id.widgetIcon, "setColorFilter", on ? 0xFF00E676 : 0xFFFFFFFF);

            Intent toggle = new Intent(context, WiFiKeeperWidget.class).setAction(ACTION_WIDGET_TOGGLE);
            PendingIntent pi = PendingIntent.getBroadcast(context, 0, toggle,
                    PendingIntent.FLAG_UPDATE_CURRENT | (android.os.Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
            rv.setOnClickPendingIntent(R.id.widgetIcon, pi);
            rv.setOnClickPendingIntent(R.id.widgetText, pi);

            awm.updateAppWidget(id, rv);
        }
    }
}
