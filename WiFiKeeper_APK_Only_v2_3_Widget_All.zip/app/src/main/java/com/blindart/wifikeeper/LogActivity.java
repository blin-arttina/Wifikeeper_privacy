package com.blindart.wifikeeper;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.OutputStream;

public class LogActivity extends AppCompatActivity {
    private static final int REQ_CREATE_DOC = 42;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);
        setTitle("WiFiKeeper Logs");

        TextView logText = findViewById(R.id.logText);
        Button btnShare = findViewById(R.id.btnShare);
        Button btnExport = findViewById(R.id.btnExport);
        Button btnClear = findViewById(R.id.btnClear);

        logText.setText(LogStore.get(this));

        btnShare.setOnClickListener(v -> {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, LogStore.get(this));
            startActivity(Intent.createChooser(share, "Share logs"));
        });

        btnExport.setOnClickListener(v -> {
            Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            create.addCategory(Intent.CATEGORY_OPENABLE);
            create.setType("text/plain");
            create.putExtra(Intent.EXTRA_TITLE, "WiFiKeeper_logs.txt");
            startActivityForResult(create, REQ_CREATE_DOC);
        });

        btnClear.setOnClickListener(v -> {
            LogStore.clear(this);
            logText.setText("");
        });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 42 && resultCode == Activity.RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try {
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    os.write(LogStore.get(this).getBytes("UTF-8"));
                    os.flush();
                    os.close();
                } catch (Exception e) {
                    LogStore.add(this, "Export failed: " + e.toString());
                }
            }
        }
    }
}
