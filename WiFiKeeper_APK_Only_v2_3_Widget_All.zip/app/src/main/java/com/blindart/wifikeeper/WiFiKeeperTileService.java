package com.blindart.wifikeeper;

import android.content.Intent;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.content.SharedPreferences;

public class WiFiKeeperTileService extends TileService {

    private boolean isOn() {
        SharedPreferences prefs = getSharedPreferences("wifikeeper", MODE_PRIVATE);
        return prefs.getBoolean("service_on", false);
    }

    private void setOn(boolean on) {
        getSharedPreferences("wifikeeper", MODE_PRIVATE).edit().putBoolean("service_on", on).apply();
    }

    @Override public void onStartListening() {
        super.onStartListening();
        Tile t = getQsTile();
        if (t != null) {
            t.setState(isOn() ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
            t.setLabel("WiFiKeeper");
            t.updateTile();
        }
    }

    @Override public void onClick() {
        super.onClick();
        boolean next = !isOn();
        setOn(next);
        Tile t = getQsTile();
        if (t != null) {
            t.setState(next ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
            t.updateTile();
        }
        if (next) {
            LogStore.add(this, "QS Tile -> start service");
            startService(new Intent(this, WiFiKeeperService.class));
        } else {
            LogStore.add(this, "QS Tile -> stop service");
            stopService(new Intent(this, WiFiKeeperService.class));
        }
        WiFiKeeperWidget.requestUpdate(this);
    }
}
