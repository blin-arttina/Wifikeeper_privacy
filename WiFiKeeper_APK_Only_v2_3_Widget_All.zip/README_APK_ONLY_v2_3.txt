WiFiKeeper v2.3 (APK-only) — Home-Screen Widget + All Features

New in 2.3:
• Home-screen widget with live ON/OFF status and one-tap toggle
• Widget text and icon tint reflect state (green when ON)
• Keeps Quick Settings tile, Notification actions (Toggle/Stop), Auto-start on app open
• Logs with Share + Export (+ crash capture), Light/Dark theme, About & Privacy (offline fallback)

Build (AIDE):
1) Copy folder to: /storage/emulated/0/AIDEProjects/WiFiKeeper_APK_Only_v2_3_Widget_All/
2) AIDE → Open Project → WiFiKeeper_APK_Only_v2_3_Widget_All
3) Build → Build APK (Release)
4) APK output:
   app/build/outputs/apk/release/WiFiKeeper_v2.3_release.apk

Add the widget:
• Long-press Home → Widgets → search "WiFiKeeper Toggle" → drag to Home screen.
• Tap icon or text to toggle; it lights up when ON.

Notes:
• Min SDK 26, Target SDK 34
• Signed release build pre-configured (keystore path in build.gradle)
• No tracking. Privacy policy available via About (with offline fallback page).
