package com.blindart.wifikeeper;

import android.os.Bundle;
import android.widget.CompoundButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;

public class SettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        setTitle("Settings");

        final SwitchCompat themeSwitch = findViewById(R.id.themeSwitch);
        final boolean light = getSharedPreferences("wifikeeper", MODE_PRIVATE).getBoolean("light_theme", false);
        themeSwitch.setChecked(light);

        themeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getSharedPreferences("wifikeeper", MODE_PRIVATE).edit().putBoolean("light_theme", isChecked).apply();
                AppCompatDelegate.setDefaultNightMode(isChecked ? AppCompatDelegate.MODE_NIGHT_NO : AppCompatDelegate.MODE_NIGHT_YES);
                recreate();
            }
        });
    }
}
