package com.blindart.wifikeeper;

import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    private static final String HOSTED_URL = "https://blindart2020.github.io/wifikeeper-privacy/";
    private static final String FALLBACK_URL = "file:///android_asset/privacy_policy.html";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        setTitle("About & Privacy");

        WebView web = findViewById(R.id.web);
        web.getSettings().setJavaScriptEnabled(false);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                view.loadUrl(FALLBACK_URL);
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        web.loadUrl(HOSTED_URL);
    }
}
