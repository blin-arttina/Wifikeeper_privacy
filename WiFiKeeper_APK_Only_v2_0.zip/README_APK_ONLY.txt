WiFiKeeper (APK-only) — Build & Install

1) Copy this folder to your phone:
   /storage/emulated/0/AIDEProjects/WiFiKeeper_APK_Only_v2_0/

2) In AIDE:
   • Open Project → WiFiKeeper_APK_Only_v2_0
   • Wait for Gradle sync to finish

3) Build a signed Release APK:
   • Menu → Build → Build APK (Release)
   • (or tap ▶ and choose Release)

4) Find the APK:
   /storage/emulated/0/AIDEProjects/WiFiKeeper_APK_Only_v2_0/app/build/outputs/apk/release/WiFiKeeper_v2.0_release.apk

5) Install:
   • Tap the APK → Allow 'install unknown apps' for your file manager if prompted.
   • If 'App not installed', uninstall any older WiFiKeeper first and retry.

Notes:
• Version: versionCode 21, versionName 2.0
• Target SDK 34, min SDK 26
• Privacy Policy (About menu): https://blindart2020.github.io/wifikeeper-privacy/
