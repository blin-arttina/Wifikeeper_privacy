# WiFiKeeper • Privacy Policy

This repository hosts the public privacy policy for the WiFiKeeper Android app.

## How to publish with GitHub Pages
1. Create a new public repo named `wifikeeper-privacy` (or any name you like).
2. Add `index.html` from this folder to the root of the repo.
3. In **Settings → Pages**, set **Source** to "Deploy from a branch" and pick the branch (e.g., `main`) and `/ (root)` folder.
4. Save. After a short delay, your policy will be live at:

```
https://<your-github-username>.github.io/wifikeeper-privacy/
```

## Contact
Questions? Email **blindart2020@gmail.com**.
