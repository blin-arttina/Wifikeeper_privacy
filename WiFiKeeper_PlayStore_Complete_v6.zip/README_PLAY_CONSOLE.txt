WiFiKeeper v1.9 — Play Console (AAB) Build Guide

New app uploads on Google Play require an Android App Bundle (.aab).
This project is configured for that. Build your AAB using Android Studio on a PC/Mac.

Option A — Android Studio (recommended)
--------------------------------------
1) Open Android Studio → Open → select the WiFiKeeper folder.
2) Let it sync Gradle.
3) Build → Generate Signed Bundle / APK…
4) Choose "Android App Bundle".
5) Create new or use your existing keystore:
   • Keystore: /storage/emulated/0/AIDEProjects/keystores/wifikeeper-release.keystore
   • Alias: wifikeeper
   • Passwords: changeit123
6) Finish. The AAB output is under:
   app/build/outputs/bundle/release/app-release.aab
7) In Play Console, upload this AAB.
   (If prompted, opt-in to Play App Signing — recommended.)

Option B — On-device build (advanced)
-------------------------------------
AIDE typically builds APKs, not AABs. If you must build on-device, you can use Termux + Gradle, but it's heavier:
• Install JDK 11 and Gradle.
• Run: ./gradlew bundleRelease
This produces: app/build/outputs/bundle/release/app-release.aab

Notes
-----
• Version: versionCode 10, versionName 1.9
• Target SDK 34
• Privacy Policy URL (About menu): https://blindart2020.github.io/wifikeeper-privacy/
• Data Safety blurb (no data collected) is included in earlier message.
