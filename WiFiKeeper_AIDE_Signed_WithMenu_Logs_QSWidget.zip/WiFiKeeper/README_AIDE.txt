WiFiKeeper — AIDE-ready (Java), signed, now with Quick Settings Tile + Home Widget

Install & build (copy/paste):
1) Unzip 'WiFiKeeper' into: /storage/emulated/0/AIDEProjects/
2) Ensure keystore exists at: /storage/emulated/0/AIDEProjects/keystores/wifikeeper-release.keystore
3) AIDE → Open Project → WiFiKeeper
4) Build → Build APK (Release)
5) Install from: app/build/outputs/apk/release/app-release.apk

New:
• Quick Settings Tile (pull down shade → edit tiles → add “WiFiKeeper”)
• Home screen Widget (long‑press home → Widgets → WiFiKeeper → add)
• Taps toggle the background service
Existing:
• Foreground service with Wi‑Fi high‑perf + CPU partial wakelock
• Persistent notification, auto‑reconnect, start on boot
• Menu: Settings / Privacy / About / Logs (Copy/Share/Clear)
• Dark mode default; footer “Blind Art 2025”
