
package com.example.wifikeeper;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.wifikeeper.core.LogStore;

public class LogActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);
        setTitle("Logs");

        TextView logText = findViewById(R.id.logText);
        Button copy = findViewById(R.id.btnCopy);
        Button share = findViewById(R.id.btnShare);
        Button clear = findViewById(R.id.btnClear);

        logText.setText(LogStore.get(this));

        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("WiFiKeeper Logs", LogStore.get(this)));
        });

        share.setOnClickListener(v -> {
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            s.putExtra(Intent.EXTRA_TEXT, LogStore.get(this));
            startActivity(Intent.createChooser(s, "Share logs"));
        });

        clear.setOnClickListener(v -> {
            LogStore.clear(this);
            logText.setText("");
        });
    }
}
