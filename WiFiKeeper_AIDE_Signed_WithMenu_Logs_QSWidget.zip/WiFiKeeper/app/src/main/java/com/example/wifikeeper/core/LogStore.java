
package com.example.wifikeeper.core;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LogStore {
    private static final String PREF = "wifikeeper_logs";
    private static final String KEY  = "log_text";
    private static final int MAX = 16000;

    public static void add(Context ctx, String msg) {
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String ts = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        String cur = sp.getString(KEY, "");
        String out = cur + ts + "  " + msg + "\n";
        if (out.length() > MAX) out = out.substring(out.length() - MAX);
        sp.edit().putString(KEY, out).apply();
    }
    public static String get(Context ctx) {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "");
    }
    public static void clear(Context ctx) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
