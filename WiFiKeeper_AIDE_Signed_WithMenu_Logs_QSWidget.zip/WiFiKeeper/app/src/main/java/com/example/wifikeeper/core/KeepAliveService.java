
package com.example.wifikeeper.core;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.example.wifikeeper.MainActivity;
import com.example.wifikeeper.R;

public class KeepAliveService extends Service {

    private static final String CH_ID = "wifikeeper.foreground";
    private static final int NOTI_ID = 77;

    private WifiManager.WifiLock wifiLock;
    private PowerManager.WakeLock cpuLock;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback callback;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        LogStore.add(this, "Service created");

        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "WiFiKeeper:WifiLock");
        wifiLock.setReferenceCounted(false);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "WiFiKeeper:CpuLock");
        cpuLock.setReferenceCounted(false);

        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        registerNetCallback();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        acquireLocks();

        PendingIntent pi = PendingIntent.getActivity(
                this, 0, new Intent(this, MainActivity.class),
                Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_IMMUTABLE : 0);

        Notification noti = new NotificationCompat.Builder(this, CH_ID)
                .setSmallIcon(R.drawable.ic_stat_wifi)
                .setContentTitle("WiFiKeeper running")
                .setContentText("Keeping Wi‑Fi and CPU awake")
                .setOngoing(true)
                .setContentIntent(pi)
                .build();

        startForeground(NOTI_ID, noti);
        LogStore.add(this, "Foreground started");
        return START_STICKY;
    }

    private void acquireLocks() {
        try { if (!wifiLock.isHeld()) { wifiLock.acquire(); LogStore.add(this, "Wi‑Fi lock acquired"); } } catch (Throwable ignored) {}
        try { if (!cpuLock.isHeld()) { cpuLock.acquire(); LogStore.add(this, "CPU wake lock acquired"); } } catch (Throwable ignored) {}
    }

    private void releaseLocks() {
        try { if (wifiLock.isHeld()) { wifiLock.release(); LogStore.add(this, "Wi‑Fi lock released"); } } catch (Throwable ignored) {}
        try { if (cpuLock.isHeld()) { cpuLock.release(); LogStore.add(this, "CPU wake lock released"); } } catch (Throwable ignored) {}
    }

    private void registerNetCallback() {
        NetworkRequest request = new NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build();

        callback = new ConnectivityManager.NetworkCallback() {
            @Override public void onLost(Network network) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (!wm.isWifiEnabled()) wm.setWifiEnabled(true);
                LogStore.add(KeepAliveService.this, "Network lost → attempting Wi‑Fi enable");
            }
        };
        connectivityManager.registerNetworkCallback(request, callback);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CH_ID, "WiFiKeeper Service",
                    NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(ch);
        }
    }

    @Override public void onDestroy() {
        super.onDestroy();
        try { connectivityManager.unregisterNetworkCallback(callback); } catch (Throwable ignored) {}
        releaseLocks();
        LogStore.add(this, "Service destroyed");
    }

    @Nullable @Override public IBinder onBind(Intent intent) { return null; }
}
