
package com.example.wifikeeper.core;

import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class QuickTileService extends TileService {

    private boolean running = false;

    @Override public void onStartListening() {
        super.onStartListening();
        updateTile();
    }

    @Override public void onClick() {
        super.onClick();
        running = !running;
        Intent i = new Intent(this, KeepAliveService.class);
        if (running) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);
            LogStore.add(this, "QS tile: started service");
        } else {
            stopService(i);
            LogStore.add(this, "QS tile: stopped service");
        }
        updateTile();
    }

    private void updateTile() {
        Tile t = getQsTile();
        if (t == null) return;
        t.setState(running ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.setLabel("WiFiKeeper");
        t.updateTile();
    }
}
