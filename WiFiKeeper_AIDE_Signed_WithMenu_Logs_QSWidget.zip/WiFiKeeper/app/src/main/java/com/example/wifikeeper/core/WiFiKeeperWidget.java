
package com.example.wifikeeper.core;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;

import com.example.wifikeeper.R;

public class WiFiKeeperWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) {
            RemoteViews views = new RemoteViews(ctx.getPackageName(), R.layout.widget_wifikeeper);
            Intent toggle = new Intent(ctx, ToggleReceiver.class).setAction("com.example.wifikeeper.TOGGLE_SERVICE");
            int flags = Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_IMMUTABLE : 0;
            PendingIntent pi = PendingIntent.getBroadcast(ctx, 0, toggle, flags);
            views.setOnClickPendingIntent(R.id.btnWidgetToggle, pi);
            mgr.updateAppWidget(id, views);
        }
    }
}
