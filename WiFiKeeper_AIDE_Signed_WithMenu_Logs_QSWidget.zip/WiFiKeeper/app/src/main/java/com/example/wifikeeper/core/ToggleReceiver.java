
package com.example.wifikeeper.core;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ToggleReceiver extends BroadcastReceiver {
    private static boolean running = false;

    @Override public void onReceive(Context context, Intent intent) {
        Intent svc = new Intent(context, KeepAliveService.class);
        if (!running) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(svc);
            else context.startService(svc);
            LogStore.add(context, "Widget: started service");
        } else {
            context.stopService(svc);
            LogStore.add(context, "Widget: stopped service");
        }
        running = !running;
    }
}
