WiFiKeeper Play Store Complete (v2) — with Privacy Policy
---------------------------------------------------------
• Wi‑Fi toggle UI (color changes on ON/OFF)
• Adaptive icon + legacy PNGs
• In‑app Privacy Policy (Menu → About & Privacy)
• Target SDK 34
• Prewired signing to your keystore:
  /storage/emulated/0/AIDEProjects/keystores/wifikeeper-release.keystore
