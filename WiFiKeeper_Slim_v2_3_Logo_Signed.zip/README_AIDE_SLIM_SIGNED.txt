WiFiKeeper Slim v2.3 — AIDE Quick Open + Blind Art Logo + Release Signing

Unzip to:
/storage/emulated/0/AIDEProjects/WiFiKeeper_Slim_v2_3_Logo_Signed/

AIDE → Projects → Open Project → WiFiKeeper_Slim_v2_3_Logo_Signed
Build → Build APK (Release)
APK: app/build/outputs/apk/release/app-release.apk

Blind Art logo:
• Replace placeholder at res/drawable/blind_art_logo.xml with your PNG file if you prefer:
  - Put your file at: app/src/main/res/drawable-nodpi/blind_art_logo.png
  - Then change ImageView src to @drawable/blind_art_logo (no extension).
  - XML ImageView already points to @drawable/blind_art_logo.

Signing (edit if needed):
• app/build.gradle has a signingConfigs.release block.
• Update storeFile, storePassword, keyAlias, keyPassword to match your keystore.
• If you don't want signing, remove signingConfig lines from buildTypes.
