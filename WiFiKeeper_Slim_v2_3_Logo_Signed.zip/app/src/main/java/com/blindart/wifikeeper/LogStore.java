package com.blindart.wifikeeper;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LogStore {
    private static final String PREF = "wifikeeper_logs";
    private static final String KEY = "log_text";
    private static final int MAX_CHARS = 16000;

    public static void add(Context ctx, String line) {
        SharedPreferences sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String now = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        String entry = now + "  " + line + "\n";
        String cur = sp.getString(KEY, "");
        String out = cur + entry;
        if (out.length() > MAX_CHARS) {
            out = out.substring(out.length() - MAX_CHARS);
        }
        sp.edit().putString(KEY, out).apply();
    }

    public static String get(Context ctx) {
        return ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "");
    }

    public static void clear(Context ctx) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
