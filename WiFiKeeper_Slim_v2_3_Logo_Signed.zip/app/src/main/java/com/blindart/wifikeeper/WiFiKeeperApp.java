package com.blindart.wifikeeper;

import android.app.Application;

public class WiFiKeeperApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            StringBuilder sb = new StringBuilder();
            sb.append("FATAL: ").append(e.toString()).append("\n");
            for (StackTraceElement el : e.getStackTrace()) {
                sb.append("  at ").append(el.toString()).append("\n");
            }
            LogStore.add(getApplicationContext(), sb.toString());
        });
    }
}
