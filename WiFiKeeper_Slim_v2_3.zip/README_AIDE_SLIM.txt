WiFiKeeper Slim v2.3 — AIDE-Quick Open

Copy to:
/storage/emulated/0/AIDEProjects/WiFiKeeper_Slim_v2_3/

Open in AIDE:
Projects → Open Project → WiFiKeeper_Slim_v2_3

Build:
Build → Build APK (Release)
APK location:
app/build/outputs/apk/release/app-release.apk

Notes:
• Same features as v2.3 (widget, notification actions, logs export/share, auto-start, privacy page).
• Uses default debug keystore (no signing setup needed).

Add Widget:
Long-press Home → Widgets → "WiFiKeeper Toggle" → drag to Home.
